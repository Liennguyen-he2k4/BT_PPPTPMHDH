﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ap4;
namespace ap4
{
    public partial class Form1 : Form
    {
        private Label lblDanhSach;
        private ListBox lstDanhSachMatHang;
        private Label lblLuaChon;
        private ListBox lstMatHangLuaChon;
        private Button btnChuyenSang;
        private Button btnChuyenTatCaSang;
        private Button btnChuyenVe;
        private Button btnChuyenTatCaVe;

        public Form1()
        {
            InitializeComponent();
            LoadInitialData();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form
            this.Text = "Bài tập 7";
            this.Size = new Size(650, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.LightGray;

            // Label Danh sách các mặt hàng
            this.lblDanhSach = new Label();
            this.lblDanhSach.Location = new Point(30, 20);
            this.lblDanhSach.Size = new Size(200, 25);
            this.lblDanhSach.Text = "Danh sách các mặt hàng";
            this.lblDanhSach.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // ListBox Danh sách mặt hàng
            this.lstDanhSachMatHang = new ListBox();
            this.lstDanhSachMatHang.Location = new Point(30, 50);
            this.lstDanhSachMatHang.Size = new Size(200, 250);
            this.lstDanhSachMatHang.Font = new Font("Microsoft Sans Serif", 9);
            this.lstDanhSachMatHang.SelectionMode = SelectionMode.MultiExtended;
            this.lstDanhSachMatHang.BackColor = Color.White;

            // Label Các mặt hàng lựa chọn
            this.lblLuaChon = new Label();
            this.lblLuaChon.Location = new Point(380, 20);
            this.lblLuaChon.Size = new Size(200, 25);
            this.lblLuaChon.Text = "Các mặt hàng lựa chọn";
            this.lblLuaChon.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // ListBox Mặt hàng lựa chọn
            this.lstMatHangLuaChon = new ListBox();
            this.lstMatHangLuaChon.Location = new Point(380, 50);
            this.lstMatHangLuaChon.Size = new Size(200, 250);
            this.lstMatHangLuaChon.Font = new Font("Microsoft Sans Serif", 9);
            this.lstMatHangLuaChon.SelectionMode = SelectionMode.MultiExtended;
            this.lstMatHangLuaChon.BackColor = Color.White;

            // Button > (Chuyển sang)
            this.btnChuyenSang = new Button();
            this.btnChuyenSang.Location = new Point(270, 80);
            this.btnChuyenSang.Size = new Size(60, 30);
            this.btnChuyenSang.Text = ">";
            this.btnChuyenSang.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);
            this.btnChuyenSang.UseVisualStyleBackColor = true;
            this.btnChuyenSang.Click += new EventHandler(this.btnChuyenSang_Click);

            // Button >> (Chuyển tất cả sang)
            this.btnChuyenTatCaSang = new Button();
            this.btnChuyenTatCaSang.Location = new Point(270, 120);
            this.btnChuyenTatCaSang.Size = new Size(60, 30);
            this.btnChuyenTatCaSang.Text = ">>";
            this.btnChuyenTatCaSang.Font = new Font("Microsoft Sans Serif", 11, FontStyle.Bold);
            this.btnChuyenTatCaSang.UseVisualStyleBackColor = true;
            this.btnChuyenTatCaSang.Click += new EventHandler(this.btnChuyenTatCaSang_Click);

            // Button < (Chuyển về)
            this.btnChuyenVe = new Button();
            this.btnChuyenVe.Location = new Point(270, 160);
            this.btnChuyenVe.Size = new Size(60, 30);
            this.btnChuyenVe.Text = "<";
            this.btnChuyenVe.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);
            this.btnChuyenVe.UseVisualStyleBackColor = true;
            this.btnChuyenVe.Click += new EventHandler(this.btnChuyenVe_Click);

            // Button << (Chuyển tất cả về)
            this.btnChuyenTatCaVe = new Button();
            this.btnChuyenTatCaVe.Location = new Point(270, 200);
            this.btnChuyenTatCaVe.Size = new Size(60, 30);
            this.btnChuyenTatCaVe.Text = "<<";
            this.btnChuyenTatCaVe.Font = new Font("Microsoft Sans Serif", 11, FontStyle.Bold);
            this.btnChuyenTatCaVe.UseVisualStyleBackColor = true;
            this.btnChuyenTatCaVe.Click += new EventHandler(this.btnChuyenTatCaVe_Click);

            // Add all controls to form
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.lstDanhSachMatHang);
            this.Controls.Add(this.lblLuaChon);
            this.Controls.Add(this.lstMatHangLuaChon);
            this.Controls.Add(this.btnChuyenSang);
            this.Controls.Add(this.btnChuyenTatCaSang);
            this.Controls.Add(this.btnChuyenVe);
            this.Controls.Add(this.btnChuyenTatCaVe);

            this.ResumeLayout(false);
        }

        private void LoadInitialData()
        {
            // Thêm dữ liệu mặc định vào danh sách các mặt hàng
            List<string> matHangs = new List<string>
            {
                "CPU",
                "HardBoard",
                "RAM",
                "Keyboard",
                "Mouse",
                "HDD",
                "Fan"
            };

            foreach (string matHang in matHangs)
            {
                lstDanhSachMatHang.Items.Add(matHang);
            }
        }

        // Chuyển các mục được chọn từ danh sách mặt hàng sang danh sách lựa chọn
        private void btnChuyenSang_Click(object sender, EventArgs e)
        {
            if (lstDanhSachMatHang.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất một mặt hàng để chuyển!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Lưu các item được chọn vào list tạm
            List<object> selectedItems = new List<object>();
            foreach (object item in lstDanhSachMatHang.SelectedItems)
            {
                selectedItems.Add(item);
            }

            // Chuyển các item sang listbox đích và xóa khỏi listbox nguồn
            foreach (object item in selectedItems)
            {
                if (!lstMatHangLuaChon.Items.Contains(item))
                {
                    lstMatHangLuaChon.Items.Add(item);
                }
                lstDanhSachMatHang.Items.Remove(item);
            }

            // Sắp xếp lại danh sách
            SortListBox(lstMatHangLuaChon);
        }

        // Chuyển tất cả mặt hàng sang danh sách lựa chọn
        private void btnChuyenTatCaSang_Click(object sender, EventArgs e)
        {
            if (lstDanhSachMatHang.Items.Count == 0)
            {
                MessageBox.Show("Danh sách mặt hàng đã trống!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Chuyển tất cả items
            List<object> allItems = new List<object>();
            foreach (object item in lstDanhSachMatHang.Items)
            {
                allItems.Add(item);
            }

            foreach (object item in allItems)
            {
                if (!lstMatHangLuaChon.Items.Contains(item))
                {
                    lstMatHangLuaChon.Items.Add(item);
                }
            }

            lstDanhSachMatHang.Items.Clear();
            SortListBox(lstMatHangLuaChon);
        }

        // Chuyển các mục được chọn từ danh sách lựa chọn về danh sách mặt hàng
        private void btnChuyenVe_Click(object sender, EventArgs e)
        {
            if (lstMatHangLuaChon.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất một mặt hàng để chuyển về!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Lưu các item được chọn vào list tạm
            List<object> selectedItems = new List<object>();
            foreach (object item in lstMatHangLuaChon.SelectedItems)
            {
                selectedItems.Add(item);
            }

            // Chuyển các item về listbox nguồn và xóa khỏi listbox đích
            foreach (object item in selectedItems)
            {
                if (!lstDanhSachMatHang.Items.Contains(item))
                {
                    lstDanhSachMatHang.Items.Add(item);
                }
                lstMatHangLuaChon.Items.Remove(item);
            }

            // Sắp xếp lại danh sách
            SortListBox(lstDanhSachMatHang);
        }

        // Chuyển tất cả mặt hàng về danh sách ban đầu
        private void btnChuyenTatCaVe_Click(object sender, EventArgs e)
        {
            if (lstMatHangLuaChon.Items.Count == 0)
            {
                MessageBox.Show("Danh sách lựa chọn đã trống!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Chuyển tất cả items về
            List<object> allItems = new List<object>();
            foreach (object item in lstMatHangLuaChon.Items)
            {
                allItems.Add(item);
            }

            foreach (object item in allItems)
            {
                if (!lstDanhSachMatHang.Items.Contains(item))
                {
                    lstDanhSachMatHang.Items.Add(item);
                }
            }

            lstMatHangLuaChon.Items.Clear();
            SortListBox(lstDanhSachMatHang);
        }

        // Sắp xếp các item trong ListBox theo thứ tự alphabet
        private void SortListBox(ListBox listBox)
        {
            List<string> items = new List<string>();
            foreach (object item in listBox.Items)
            {
                items.Add(item.ToString());
            }

            items.Sort();
            listBox.Items.Clear();

            foreach (string item in items)
            {
                listBox.Items.Add(item);
            }
        }
    }
    
}