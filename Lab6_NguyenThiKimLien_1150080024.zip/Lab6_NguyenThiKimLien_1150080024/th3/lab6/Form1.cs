﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using lab6;
namespace lab6 
{
    public class Form1 : Form
    {
        Label lblTieuDe, lblDanhSach, lblChonBan;
        PictureBox pictureLogo;
        FlowLayoutPanel panelMonAn;
        ComboBox comboBoxBan;
        Button btnOrder, btnXoa;
        ListBox listBoxOrder;

        public Form1()
        {
            // Cấu hình form
            this.Text = "Quán ăn nhanh Hưng Thịnh";
            this.Size = new Size(600, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Logo
            pictureLogo = new PictureBox();
            pictureLogo.Size = new Size(80, 80);
            pictureLogo.Location = new Point(10, 10);
            pictureLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            try
            {
                pictureLogo.Image = Image.FromFile("burger.png"); // ảnh trong cùng thư mục .exe
            }
            catch
            {
                pictureLogo.BackColor = Color.LightGray;
                pictureLogo.BorderStyle = BorderStyle.FixedSingle;
            }

            // Tiêu đề
            lblTieuDe = new Label();
            lblTieuDe.Text = "Quán ăn nhanh Hưng Thịnh";
            lblTieuDe.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.White;
            lblTieuDe.BackColor = Color.Green;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Location = new Point(100, 25);
            lblTieuDe.Size = new Size(450, 50);

            // Danh sách món ăn
            lblDanhSach = new Label();
            lblDanhSach.Text = "Danh sách món ăn:";
            lblDanhSach.Font = new Font("Segoe UI", 10, FontStyle.Regular);
            lblDanhSach.Location = new Point(10, 100);
            lblDanhSach.Size = new Size(200, 20);

            // Panel chứa các nút món ăn
            panelMonAn = new FlowLayoutPanel();
            panelMonAn.Location = new Point(10, 130);
            panelMonAn.Size = new Size(560, 160);
            panelMonAn.WrapContents = true;

            string[] monAn = {
                "Cơm chiên trứng", "Bánh mì ốp la", "Coca", "Lipton",
                "Ốc rang muối", "Khoai tây chiên", "7 up", "Cam",
                "Mỳ xào hải sản", "Cá viên chiên", "Pepsi", "Cafe",
                "Buger bò nướng", "Đùi gà rán", "Bún bò Huế"
            };

            foreach (string item in monAn)
            {
                Button btn = new Button();
                btn.Text = item;
                btn.Width = 120;
                btn.Height = 30;
                btn.Margin = new Padding(5);
                btn.Click += BtnMonAn_Click;
                panelMonAn.Controls.Add(btn);
            }

            // Nút Xóa
            btnXoa = new Button();
            btnXoa.Text = "Xóa";
            btnXoa.Location = new Point(10, 310);
            btnXoa.Click += BtnXoa_Click;

            // Label chọn bàn
            lblChonBan = new Label();
            lblChonBan.Text = "Chọn bàn:";
            lblChonBan.Location = new Point(100, 315);
            lblChonBan.Size = new Size(70, 20);

            // ComboBox bàn
            comboBoxBan = new ComboBox();
            comboBoxBan.Location = new Point(170, 312);
            comboBoxBan.Width = 100;
            comboBoxBan.Items.AddRange(new string[]
            {
                "Bàn 1", "Bàn 2", "Bàn 3", "Bàn 4", "Bàn 5"
            });
            comboBoxBan.SelectedIndex = 0;

            // Nút Order
            btnOrder = new Button();
            btnOrder.Text = "Order";
            btnOrder.Location = new Point(290, 310);
            btnOrder.Click += BtnOrder_Click;

            // ListBox hiển thị order
            listBoxOrder = new ListBox();
            listBoxOrder.Location = new Point(10, 350);
            listBoxOrder.Size = new Size(560, 150);

            // Thêm tất cả control vào form
            this.Controls.Add(pictureLogo);
            this.Controls.Add(lblTieuDe);
            this.Controls.Add(lblDanhSach);
            this.Controls.Add(panelMonAn);
            this.Controls.Add(btnXoa);
            this.Controls.Add(lblChonBan);
            this.Controls.Add(comboBoxBan);
            this.Controls.Add(btnOrder);
            this.Controls.Add(listBoxOrder);
        }

        // ====== Sự kiện ======
        private void BtnMonAn_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            listBoxOrder.Items.Add(btn.Text);
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            listBoxOrder.Items.Clear();
        }

        private void BtnOrder_Click(object sender, EventArgs e)
        {
            if (listBoxOrder.Items.Count == 0)
            {
                MessageBox.Show("Bạn chưa chọn món!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string ban = comboBoxBan.SelectedItem?.ToString() ?? "Chưa chọn bàn";
            MessageBox.Show($"Đã đặt món cho {ban}!\nTổng món: {listBoxOrder.Items.Count}", "Order thành công");
        }
    }
}
