﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab32
{
    public class Form1 : Form
    {
        // Khai báo các control
        Label lblTitle, lblHoTen, lblNgaySinh, lblLop, lblDiaChi;
        TextBox txtHoTen, txtLop, txtDiaChi;
        DateTimePicker dtNgaySinh;
        Button btnThem, btnXoa, btnSua, btnThoat;
        ListView lvSinhVien;
        GroupBox gbThongTin, gbDanhSach;

        public Form1()
        {
            // ======== Thiết lập form ========
            this.Text = "Danh sách sinh viên";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            // ======== Tiêu đề ========
            lblTitle = new Label();
            lblTitle.Text = "DANH MỤC SINH VIÊN";
            lblTitle.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            lblTitle.ForeColor = Color.Blue;
            lblTitle.AutoSize = false;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Top;
            lblTitle.Height = 50;

            // ======== GroupBox Thông tin sinh viên ========
            gbThongTin = new GroupBox();
            gbThongTin.Text = "Thông tin sinh viên";
            gbThongTin.SetBounds(20, 60, 640, 150);

            lblHoTen = new Label() { Text = "Họ tên:", Left = 20, Top = 30, Width = 80 };
            lblNgaySinh = new Label() { Text = "Ngày sinh:", Left = 20, Top = 70, Width = 80 };
            lblLop = new Label() { Text = "Lớp:", Left = 330, Top = 30, Width = 50 };
            lblDiaChi = new Label() { Text = "Địa chỉ:", Left = 330, Top = 70, Width = 50 };

            txtHoTen = new TextBox() { Left = 100, Top = 28, Width = 200 };
            txtLop = new TextBox() { Left = 380, Top = 28, Width = 200 };
            dtNgaySinh = new DateTimePicker() { Left = 100, Top = 68, Width = 200, Format = DateTimePickerFormat.Short };
            txtDiaChi = new TextBox() { Left = 380, Top = 68, Width = 200 };

            // Nút lệnh
            btnThem = new Button() { Text = "Thêm", Left = 100, Top = 110, Width = 80 };
            btnSua = new Button() { Text = "Sửa", Left = 200, Top = 110, Width = 80 };
            btnXoa = new Button() { Text = "Xóa", Left = 300, Top = 110, Width = 80 };
            btnThoat = new Button() { Text = "Thoát", Left = 400, Top = 110, Width = 80 };

            btnThem.Click += BtnThem_Click;
            btnXoa.Click += BtnXoa_Click;
            btnSua.Click += BtnSua_Click;
            btnThoat.Click += (s, e) => this.Close();

            gbThongTin.Controls.AddRange(new Control[]
            {
                lblHoTen, txtHoTen, lblNgaySinh, dtNgaySinh,
                lblLop, txtLop, lblDiaChi, txtDiaChi,
                btnThem, btnSua, btnXoa, btnThoat
            });

            // ======== GroupBox Thông tin chung ========
            gbDanhSach = new GroupBox();
            gbDanhSach.Text = "Thông tin chung sinh viên";
            gbDanhSach.SetBounds(20, 230, 640, 200);

            lvSinhVien = new ListView();
            lvSinhVien.View = View.Details;
            lvSinhVien.FullRowSelect = true;
            lvSinhVien.GridLines = true;
            lvSinhVien.Bounds = new Rectangle(10, 20, 620, 160);

            lvSinhVien.Columns.Add("Họ tên", 150);
            lvSinhVien.Columns.Add("Ngày sinh", 120);
            lvSinhVien.Columns.Add("Lớp", 100);
            lvSinhVien.Columns.Add("Địa chỉ", 200);

            lvSinhVien.SelectedIndexChanged += LvSinhVien_SelectedIndexChanged;

            gbDanhSach.Controls.Add(lvSinhVien);

            // ======== Thêm tất cả vào form ========
            this.Controls.AddRange(new Control[] { lblTitle, gbThongTin, gbDanhSach });
        }

        // ================== CÁC SỰ KIỆN ==================

        private void BtnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem item = new ListViewItem(txtHoTen.Text);
            item.SubItems.Add(dtNgaySinh.Value.ToShortDateString());
            item.SubItems.Add(txtLop.Text);
            item.SubItems.Add(txtDiaChi.Text);

            lvSinhVien.Items.Add(item);
            ClearInput();
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn 1 sinh viên để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Bạn có chắc muốn xóa sinh viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                lvSinhVien.Items.Remove(lvSinhVien.SelectedItems[0]);
            }
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn 1 sinh viên để sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            ListViewItem item = lvSinhVien.SelectedItems[0];
            item.Text = txtHoTen.Text;
            item.SubItems[1].Text = dtNgaySinh.Value.ToShortDateString();
            item.SubItems[2].Text = txtLop.Text;
            item.SubItems[3].Text = txtDiaChi.Text;

            MessageBox.Show("Đã cập nhật thông tin sinh viên!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void LvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;

            ListViewItem item = lvSinhVien.SelectedItems[0];
            txtHoTen.Text = item.Text;
            dtNgaySinh.Value = DateTime.Parse(item.SubItems[1].Text);
            txtLop.Text = item.SubItems[2].Text;
            txtDiaChi.Text = item.SubItems[3].Text;
        }

        private void ClearInput()
        {
            txtHoTen.Clear();
            txtLop.Clear();
            txtDiaChi.Clear();
            txtHoTen.Focus();
        }


    }
}
