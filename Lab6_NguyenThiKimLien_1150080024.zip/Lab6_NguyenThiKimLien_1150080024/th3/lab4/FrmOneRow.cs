﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab4
{
    public partial class FrmOneRow : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        public FrmOneRow()
        {
            InitializeComponent();
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            string maSV = txtMaSV.Text.Trim();
            string sql = "SELECT * FROM SinhVien WHERE MaSV=@maSV";

            SqlCommand cmd = new SqlCommand(sql, sqlCon);
            cmd.Parameters.AddWithValue("@maSV", maSV);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                txtTenSV.Text = reader["HoTen"].ToString();
                txtGioiTinh.Text = reader["GioiTinh"].ToString();
                txtNgaySinh.Text = Convert.ToDateTime(reader["NgaySinh"]).ToString("dd/MM/yyyy");
                txtQueQuan.Text = reader["DiaChi"].ToString();
                txtMaLop.Text = reader["MaLop"].ToString();
            }
            else
            {
                MessageBox.Show("Không tìm thấy sinh viên có mã " + maSV);
            }
            reader.Close();
        }
    }
}
