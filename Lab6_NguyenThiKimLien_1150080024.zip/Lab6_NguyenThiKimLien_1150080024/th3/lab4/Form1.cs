﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace lab4
{
    public class From1 : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        ComboBox cbLuaChon;
        Button btnThucHien;
        TextBox txtInput;
        ListView lvOutput;

        public From1()
        {
            // ====== THIẾT KẾ GIAO DIỆN ======
            this.Text = "Thực hành 2 - Truy vấn dữ liệu";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            Label lblTitle = new Label();
            lblTitle.Text = "Chọn loại truy vấn:";
            lblTitle.Location = new Point(30, 30);
            lblTitle.AutoSize = true;
            this.Controls.Add(lblTitle);

            cbLuaChon = new ComboBox();
            cbLuaChon.Location = new Point(180, 25);
            cbLuaChon.Width = 350;
            cbLuaChon.Items.AddRange(new string[] {
                "1. Truy vấn lấy 1 giá trị (đếm sinh viên)",
                "2. Truy vấn lấy 1 dòng dữ liệu (theo mã SV)",
                "3. Truy vấn lấy nhiều dòng dữ liệu",
                "4. Truy vấn có Parameter (lớp theo khoa)",
                "5. Áp dụng: sinh viên theo mã lớp"
            });
            cbLuaChon.SelectedIndex = 0;
            this.Controls.Add(cbLuaChon);

            Label lblNhap = new Label();
            lblNhap.Text = "Nhập dữ liệu (nếu cần):";
            lblNhap.Location = new Point(30, 70);
            lblNhap.AutoSize = true;
            this.Controls.Add(lblNhap);

            txtInput = new TextBox();
            txtInput.Location = new Point(180, 65);
            txtInput.Width = 350;
            this.Controls.Add(txtInput);

            btnThucHien = new Button();
            btnThucHien.Text = "Thực hiện truy vấn";
            btnThucHien.Location = new Point(560, 50);
            btnThucHien.Click += BtnThucHien_Click;
            this.Controls.Add(btnThucHien);

            lvOutput = new ListView();
            lvOutput.Location = new Point(30, 120);
            lvOutput.Size = new Size(720, 400);
            lvOutput.View = View.Details;
            this.Controls.Add(lvOutput);
        }

        // ====== SỰ KIỆN BẤM NÚT ======
        private void BtnThucHien_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon == null)
                    sqlCon = new SqlConnection(strCon);
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                string luaChon = cbLuaChon.SelectedItem.ToString();

                if (luaChon.StartsWith("1")) TruyVan1GiaTri();
                else if (luaChon.StartsWith("2")) TruyVan1Dong();
                else if (luaChon.StartsWith("3")) TruyVanNhieuDong();
                else if (luaChon.StartsWith("4")) TruyVanParameter();
                else if (luaChon.StartsWith("5")) ApDung_MaLop();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        // ====== 1. TRUY VẤN 1 GIÁ TRỊ ======
        private void TruyVan1GiaTri()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM SinhVien", sqlCon);
            int soLuong = (int)cmd.ExecuteScalar();
            MessageBox.Show($"Tổng số sinh viên là: {soLuong}", "Kết quả");
        }

        // ====== 2. TRUY VẤN 1 DÒNG ======
        private void TruyVan1Dong()
        {
            string maSV = txtInput.Text.Trim();
            if (maSV == "")
            {
                MessageBox.Show("Nhập mã sinh viên!");
                return;
            }

            SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien WHERE MaSV=@ma", sqlCon);
            cmd.Parameters.AddWithValue("@ma", maSV);
            SqlDataReader reader = cmd.ExecuteReader();

            lvOutput.Clear();
            lvOutput.Columns.Add("Mã SV", 80);
            lvOutput.Columns.Add("Họ tên", 150);
            lvOutput.Columns.Add("Ngày sinh", 100);
            lvOutput.Columns.Add("Địa chỉ", 150);
            lvOutput.Columns.Add("Mã lớp", 80);

            if (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["MaSV"].ToString());
                item.SubItems.Add(reader["HoTen"].ToString());
                item.SubItems.Add(Convert.ToDateTime(reader["NgaySinh"]).ToString("dd/MM/yyyy"));
                item.SubItems.Add(reader["DiaChi"].ToString());
                item.SubItems.Add(reader["MaLop"].ToString());
                lvOutput.Items.Add(item);
            }
            else MessageBox.Show("Không tìm thấy sinh viên!");
            reader.Close();
        }

        // ====== 3. TRUY VẤN NHIỀU DÒNG ======
        private void TruyVanNhieuDong()
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);
            SqlDataReader reader = cmd.ExecuteReader();

            lvOutput.Clear();
            lvOutput.Columns.Add("Mã SV", 80);
            lvOutput.Columns.Add("Họ tên", 150);
            lvOutput.Columns.Add("Ngày sinh", 100);
            lvOutput.Columns.Add("Địa chỉ", 150);
            lvOutput.Columns.Add("Mã lớp", 80);

            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["MaSV"].ToString());
                item.SubItems.Add(reader["HoTen"].ToString());
                item.SubItems.Add(Convert.ToDateTime(reader["NgaySinh"]).ToString("dd/MM/yyyy"));
                item.SubItems.Add(reader["DiaChi"].ToString());
                item.SubItems.Add(reader["MaLop"].ToString());
                lvOutput.Items.Add(item);
            }
            reader.Close();
        }

        // ====== 4. TRUY VẤN DÙNG PARAMETER ======
        private void TruyVanParameter()
        {
            string tenKhoa = txtInput.Text.Trim();
            if (tenKhoa == "")
            {
                MessageBox.Show("Nhập tên khoa (vd: Công nghệ thông tin)");
                return;
            }

            SqlCommand cmd = new SqlCommand("SELECT TenLop, Khoa FROM Lop WHERE Khoa=@khoa", sqlCon);
            cmd.Parameters.AddWithValue("@khoa", tenKhoa);
            SqlDataReader reader = cmd.ExecuteReader();

            lvOutput.Clear();
            lvOutput.Columns.Add("Tên lớp", 150);
            lvOutput.Columns.Add("Khoa", 200);

            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["TenLop"].ToString());
                item.SubItems.Add(reader["Khoa"].ToString());
                lvOutput.Items.Add(item);
            }
            reader.Close();
        }

        // ====== 5. ÁP DỤNG: SINH VIÊN THEO MÃ LỚP ======
        private void ApDung_MaLop()
        {
            string maLop = txtInput.Text.Trim();
            if (maLop == "")
            {
                MessageBox.Show("Nhập mã lớp (ví dụ: 1, 2, 3...)");
                return;
            }

            SqlCommand cmd = new SqlCommand("SELECT HoTen, NgaySinh, DiaChi FROM SinhVien WHERE MaLop=@malop", sqlCon);
            cmd.Parameters.AddWithValue("@malop", maLop);
            SqlDataReader reader = cmd.ExecuteReader();

            lvOutput.Clear();
            lvOutput.Columns.Add("Họ tên", 150);
            lvOutput.Columns.Add("Ngày sinh", 100);
            lvOutput.Columns.Add("Địa chỉ", 150);

            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["HoTen"].ToString());
                item.SubItems.Add(Convert.ToDateTime(reader["NgaySinh"]).ToString("dd/MM/yyyy"));
                item.SubItems.Add(reader["DiaChi"].ToString());
                lvOutput.Items.Add(item);
            }
            reader.Close();
        }

    }
}
