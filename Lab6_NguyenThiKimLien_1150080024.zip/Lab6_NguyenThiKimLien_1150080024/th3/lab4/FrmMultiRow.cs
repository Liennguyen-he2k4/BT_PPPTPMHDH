﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab4
{
    public partial class FrmMultiRow : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        public FrmMultiRow()
        {
            InitializeComponent();
        }

        private void btnXemDS_Click(object sender, EventArgs e)
        {
            lsvSinhVien.Items.Clear();

            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM SinhVien", sqlCon);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                ListViewItem lvi = new ListViewItem(reader["MaSV"].ToString());
                lvi.SubItems.Add(reader["HoTen"].ToString());
                lvi.SubItems.Add(reader["GioiTinh"].ToString());
                lvi.SubItems.Add(Convert.ToDateTime(reader["NgaySinh"]).ToString("dd/MM/yyyy"));
                lvi.SubItems.Add(reader["DiaChi"].ToString());
                lvi.SubItems.Add(reader["MaLop"].ToString());
                lsvSinhVien.Items.Add(lvi);
            }
            reader.Close();
        }
    }
}
