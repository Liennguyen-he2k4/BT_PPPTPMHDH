﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab4
{
    public partial class FrmParameter : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        public FrmParameter()
        {
            InitializeComponent();
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            lsvLop.Items.Clear();

            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            string tenKhoa = txtTenKhoa.Text.Trim();

            SqlCommand cmd = new SqlCommand("SELECT TenLop, MaLop FROM Lop WHERE Khoa = @khoa", sqlCon);
            cmd.Parameters.AddWithValue("@khoa", tenKhoa);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem lvi = new ListViewItem(reader["TenLop"].ToString());
                lvi.SubItems.Add(reader["MaLop"].ToString());
                lsvLop.Items.Add(lvi);
            }
            reader.Close();
        }
    }
}
