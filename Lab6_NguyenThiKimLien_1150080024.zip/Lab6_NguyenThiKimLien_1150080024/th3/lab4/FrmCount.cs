﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab4
{
    public partial class FrmCount : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        public FrmCount()
        {
            InitializeComponent();
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlCommand sqlCmd = new SqlCommand("SELECT COUNT(*) FROM SinhVien", sqlCon);
            int soLuong = (int)sqlCmd.ExecuteScalar();

            MessageBox.Show("Số lượng sinh viên là: " + soLuong);
        }
    }
}
