﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace lab4
{
    public partial class FrmApDung : Form
    {
        SqlConnection sqlCon = null;
        string strCon = @"Data Source=LAPTOP-RPFLC7CG\MSSQLSERVER01;
                          Initial Catalog=Student;
                          User ID=sa;
                          Password=matkhaumoi123;";

        public FrmApDung()
        {
            InitializeComponent();
            LoadLop();
        }

        private void LoadLop()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter da = new SqlDataAdapter("SELECT MaLop, TenLop FROM Lop", sqlCon);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cbLop.DataSource = dt;
            cbLop.DisplayMember = "TenLop";
            cbLop.ValueMember = "MaLop";
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            lsbSinhVien.Items.Clear();

            string maLop = cbLop.SelectedValue.ToString();
            SqlCommand cmd = new SqlCommand("SELECT HoTen FROM SinhVien WHERE MaLop=@maLop", sqlCon);
            cmd.Parameters.AddWithValue("@maLop", maLop);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
                lsbSinhVien.Items.Add(reader["HoTen"].ToString());

            reader.Close();
        }
    }
}
