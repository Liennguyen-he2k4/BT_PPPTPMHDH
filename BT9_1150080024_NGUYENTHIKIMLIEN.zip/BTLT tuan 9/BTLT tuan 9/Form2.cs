﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BTLT_tuan_8
{
    public partial class Form2 : Form
    {
        // 🔹 Kết nối trực tiếp tới SQL Server (không dùng file .mdf)

        // Nếu bạn dùng tài khoản sa thì dùng chuỗi này thay thế:
        string strCon =
@"Data Source=(LocalDB)\MSSQLLocalDB;
  AttachDbFilename=""D:\BTLT tuan 8\BTLT tuan 8\QuanLySach.mdf"";
  Integrated Security=True";


        SqlConnection sqlCon = null;

        public Form2()
        {
            InitializeComponent();
        }

        // ===================== MỞ VÀ ĐÓNG KẾT NỐI =====================
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // ===================== HIỂN THỊ DANH SÁCH NXB =====================
        private void HienThiDanhSachNXB()
        {
            try
            {
                MoKetNoi();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "HienThiNXB";
                sqlCmd.Connection = sqlCon;

                SqlDataReader reader = sqlCmd.ExecuteReader();
                lsvDanhSach.Items.Clear();

                while (reader.Read())
                {
                    string maNXB = reader.GetString(0);
                    string tenNXB = reader.GetString(1);
                    string diaChi = reader.GetString(2);

                    ListViewItem lvi = new ListViewItem(maNXB);
                    lvi.SubItems.Add(tenNXB);
                    lvi.SubItems.Add(diaChi);
                    lsvDanhSach.Items.Add(lvi);
                }

                reader.Close();
                DongKetNoi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị danh sách NXB: " + ex.Message);
            }
        }

        // ===================== HIỂN THỊ THÔNG TIN CHI TIẾT NXB =====================
        private void HienThiThongTinNXBTheoMa(string maNXB)
        {
            try
            {
                MoKetNoi();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "HienThiChiTietNXB";
                sqlCmd.Connection = sqlCon;

                SqlParameter parMaNXB = new SqlParameter("@maNXB", SqlDbType.Char);
                parMaNXB.Value = maNXB;
                sqlCmd.Parameters.Add(parMaNXB);

                SqlDataReader reader = sqlCmd.ExecuteReader();
                txtMaNXB.Text = txtTenNXB.Text = txtDiaChi.Text = "";

                if (reader.Read())
                {
                    txtMaNXB.Text = reader.GetString(0);
                    txtTenNXB.Text = reader.GetString(1);
                    txtDiaChi.Text = reader.GetString(2);
                }

                reader.Close();
                DongKetNoi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị chi tiết NXB: " + ex.Message);
            }
        }

        // ===================== SỰ KIỆN LOAD FORM =====================
        private void Form2_Load(object sender, EventArgs e)
        {
            HienThiDanhSachNXB();
        }

        // ===================== SỰ KIỆN CLICK LISTVIEW =====================
        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            ListViewItem lvi = lsvDanhSach.SelectedItems[0];
            string maNXB = lvi.SubItems[0].Text;
            HienThiThongTinNXBTheoMa(maNXB);
        }
        // =================== HÀM THÊM ===================
        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();
                string sql = "INSERT INTO NhaXuatBan VALUES(@NXB, @TenNXB, @DiaChi)";
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@NXB", txtMaNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@TenNXB", txtTenNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());
                int rows = cmd.ExecuteNonQuery();
                DongKetNoi();

                if (rows > 0)
                {
                    MessageBox.Show("✅ Thêm NXB thành công!");
                    HienThiDanhSachNXB();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi thêm NXB: " + ex.Message);
            }
        }

        // =================== HÀM SỬA ===================
        private void btnSua_Click(object sender, EventArgs e)
        {
            // Kiểm tra xem người dùng đã chọn mã NXB chưa
            if (string.IsNullOrWhiteSpace(txtMaNXB.Text))
            {
                MessageBox.Show("⚠️ Vui lòng chọn hoặc nhập mã NXB cần sửa!");
                return;
            }

            try
            {
                MoKetNoi();

                // Câu lệnh cập nhật dữ liệu
                string sql = "UPDATE NhaXuatBan SET TenNXB=@TenNXB, DiaChi=@DiaChi WHERE NXB=@NXB";

                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                cmd.Parameters.AddWithValue("@NXB", txtMaNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@TenNXB", txtTenNXB.Text.Trim());
                cmd.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text.Trim());

                int rows = cmd.ExecuteNonQuery();
                DongKetNoi();

                if (rows > 0)
                {
                    MessageBox.Show("✅ Cập nhật NXB thành công!");
                    HienThiDanhSachNXB(); // làm mới danh sách
                }
                else
                {
                    MessageBox.Show("⚠️ Không có NXB nào được cập nhật. Hãy kiểm tra lại mã NXB!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi sửa NXB: " + ex.Message);
            }
        }
        // =================== HÀM XÓA ===================
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc muốn xóa NXB này không?", "Xác nhận", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    MoKetNoi();
                    string sql = "DELETE FROM NhaXuatBan WHERE NXB=@NXB";
                    SqlCommand cmd = new SqlCommand(sql, sqlCon);
                    cmd.Parameters.AddWithValue("@NXB", txtMaNXB.Text.Trim());
                    int rows = cmd.ExecuteNonQuery();
                    DongKetNoi();

                    if (rows > 0)
                    {
                        MessageBox.Show("🗑️ Xóa NXB thành công!");
                        HienThiDanhSachNXB();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("❌ Lỗi xóa NXB: " + ex.Message);
                }
            }
        }

        // =================== LÀM MỚI FORM ===================
        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            txtMaNXB.Clear();
            txtTenNXB.Clear();
            txtDiaChi.Clear();
            HienThiDanhSachNXB();
        }

    }
}
