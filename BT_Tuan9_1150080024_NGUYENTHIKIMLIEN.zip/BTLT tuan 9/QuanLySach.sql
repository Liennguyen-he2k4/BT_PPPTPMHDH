﻿CREATE TABLE NhaXuatBan (
    NXB CHAR(10) PRIMARY KEY,
    TenNXB NVARCHAR(100),
    DiaChi NVARCHAR(500)
);
CREATE TABLE Sach (
    MaSach CHAR(10) PRIMARY KEY,
    TenSach NVARCHAR(300),
    NXB CHAR(10),
    TenTG NVARCHAR(100),
    NamXB DATETIME,
    GhiChu NVARCHAR(500),

);
--tao khoa ngoai lien ket 2 bang
alter table Sach
add foreign key(NXB) references NhaXuatBan(NXB)

--them du lieu 
INSERT INTO NhaXuatBan VALUES 
('001', N'NXB X-men', N'Quang Trung, Hà Nội'),
('002', N'Khoa học xã hội', N'Trần Phú, Hà Nội'),
('003', N'Viện văn hóa thể thao', N'Hai Bà Trưng, Hà Nội');

INSERT INTO Sach VALUES 
('S01', N'Lập trình C#', '001', N'Nguyễn Lưu', '2022-01-01', N'Không'),
('S02', N'Lập trình .NET Core', '002', N'Trọng Khải', '2019-01-01', N'Không'),
('S03', N'Lập trình Scratch', '002', N'Bá Trọng', '2022-01-01', N'Không');

CREATE PROC HienThiNXB
AS
BEGIN
    SELECT * FROM NhaXuatBan
END
GO

CREATE PROC HienThiChiTietNXB
@maNXB CHAR(10)
AS
BEGIN
    SELECT * FROM NhaXuatBan WHERE NXB=@maNXB
END