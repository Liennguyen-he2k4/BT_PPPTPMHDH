﻿using BTLT_tuan_8;
using System;
using System.Windows.Forms;

namespace BTLT_tuan_8
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form2());
        }
    }
}
