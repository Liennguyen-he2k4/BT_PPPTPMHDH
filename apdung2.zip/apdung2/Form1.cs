﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using apdung2;
namespace apdung2 
{
    public partial class Form1 : Form
    {
        private Label lblPassword;
        private TextBox txtPassword;
        private Label lblKeyboard;
        private Button[] numberButtons;
        private Button btnClear;
        private Button btnEnter;
        private Button btnRING;
        private Label lblLoginLog;
        private ListView lvLoginLog;

        // Dictionary chứa password và tên nhóm tương ứng
        private Dictionary<string, string> passwordGroups;

        public Form1()
        {
            InitializeComponent();
            InitializePasswordGroups();
            InitializeLoginLog();
        }

        private void InitializePasswordGroups()
        {
            passwordGroups = new Dictionary<string, string>
            {
                {"1496", "Phát triển công nghệ"},
                {"2673", "Phát triển công nghệ"},
                {"7462", "Nghiên cứu viên"},
                {"8884", "Thiết kế mô hình"},
                {"3842", "Thiết kế mô hình"},
                {"3383", "Thiết kế mô hình"}
            };
        }

        private void InitializeLoginLog()
        {
            // Thêm các cột cho ListView
            lvLoginLog.Columns.Add("Ngày giờ", 150);
            lvLoginLog.Columns.Add("Nhóm", 150);
            lvLoginLog.Columns.Add("Kết quả", 100);
            lvLoginLog.View = View.Details;
            lvLoginLog.FullRowSelect = true;
            lvLoginLog.GridLines = true;
        }

        private void InitializeComponent()
        {
            this.lblPassword = new Label();
            this.txtPassword = new TextBox();
            this.lblKeyboard = new Label();
            this.btnClear = new Button();
            this.btnEnter = new Button();
            this.btnRING = new Button();
            this.lblLoginLog = new Label();
            this.lvLoginLog = new ListView();
            this.numberButtons = new Button[10];

            this.SuspendLayout();

            // Form
            this.Text = "Form1";
            this.Size = new Size(500, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.LightGray;

            // Label Password
            this.lblPassword.Location = new Point(50, 30);
            this.lblPassword.Size = new Size(80, 25);
            this.lblPassword.Text = "Password:";
            this.lblPassword.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // TextBox Password
            this.txtPassword.Location = new Point(50, 60);
            this.txtPassword.Size = new Size(350, 30);
            this.txtPassword.Font = new Font("Microsoft Sans Serif", 12);
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.ReadOnly = true;

            // Label Keyboard
            this.lblKeyboard.Location = new Point(50, 110);
            this.lblKeyboard.Size = new Size(80, 25);
            this.lblKeyboard.Text = "Keyboard:";
            this.lblKeyboard.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // Tạo các nút số từ 1-9
            int buttonIndex = 1;
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    this.numberButtons[buttonIndex] = new Button();
                    this.numberButtons[buttonIndex].Location = new Point(50 + col * 60, 150 + row * 50);
                    this.numberButtons[buttonIndex].Size = new Size(50, 40);
                    this.numberButtons[buttonIndex].Text = buttonIndex.ToString();
                    this.numberButtons[buttonIndex].Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);
                    this.numberButtons[buttonIndex].UseVisualStyleBackColor = true;
                    int capturedIndex = buttonIndex; // Capture for closure
                    this.numberButtons[buttonIndex].Click += (s, e) => NumberButton_Click(capturedIndex);
                    buttonIndex++;
                }
            }

            // Nút số 0
            this.numberButtons[0] = new Button();
            this.numberButtons[0].Location = new Point(110, 300);
            this.numberButtons[0].Size = new Size(50, 40);
            this.numberButtons[0].Text = "0";
            this.numberButtons[0].Font = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);
            this.numberButtons[0].UseVisualStyleBackColor = true;
            this.numberButtons[0].Click += (s, e) => NumberButton_Click(0);

            // Button Clear
            this.btnClear.Location = new Point(250, 150);
            this.btnClear.Size = new Size(80, 40);
            this.btnClear.Text = "Clear";
            this.btnClear.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            this.btnClear.BackColor = Color.Yellow;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // Button Enter
            this.btnEnter.Location = new Point(250, 200);
            this.btnEnter.Size = new Size(80, 40);
            this.btnEnter.Text = "Enter";
            this.btnEnter.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            this.btnEnter.BackColor = Color.LimeGreen;
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new EventHandler(this.btnEnter_Click);

            // Button RING
            this.btnRING.Location = new Point(250, 250);
            this.btnRING.Size = new Size(80, 40);
            this.btnRING.Text = "RING";
            this.btnRING.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            this.btnRING.BackColor = Color.Red;
            this.btnRING.ForeColor = Color.White;
            this.btnRING.UseVisualStyleBackColor = false;
            this.btnRING.Click += new EventHandler(this.btnRING_Click);

            // Label Login Log
            this.lblLoginLog.Location = new Point(50, 360);
            this.lblLoginLog.Size = new Size(100, 25);
            this.lblLoginLog.Text = "Login Log:";
            this.lblLoginLog.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // ListView Login Log
            this.lvLoginLog.Location = new Point(50, 390);
            this.lvLoginLog.Size = new Size(400, 150);
            this.lvLoginLog.Font = new Font("Microsoft Sans Serif", 9);

            // Add all controls to form
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblKeyboard);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.btnRING);
            this.Controls.Add(this.lblLoginLog);
            this.Controls.Add(this.lvLoginLog);

            // Add number buttons
            for (int i = 0; i <= 9; i++)
            {
                this.Controls.Add(this.numberButtons[i]);
            }

            this.ResumeLayout(false);
        }

        private void NumberButton_Click(int number)
        {
            if (txtPassword.Text.Length < 10) // Giới hạn độ dài password
            {
                txtPassword.Text += number.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPassword.Clear();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string enteredPassword = txtPassword.Text;
            string currentTime = DateTime.Now.ToString("M/d/yyyy h:mm:ss tt");

            if (string.IsNullOrEmpty(enteredPassword))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem item = new ListViewItem(currentTime);

            if (passwordGroups.ContainsKey(enteredPassword))
            {
                // Mật khẩu đúng - chấp nhận
                string groupName = passwordGroups[enteredPassword];
                item.SubItems.Add(groupName);
                item.SubItems.Add("Chấp nhận");
                item.BackColor = Color.LightGreen;

                MessageBox.Show($"Chào mừng nhóm {groupName}!\nTruy cập được chấp nhận.",
                    "Truy cập thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Mật khẩu sai - từ chối
                item.SubItems.Add("Không có");
                item.SubItems.Add("Từ chối!");
                item.BackColor = Color.LightCoral;

                MessageBox.Show("Mật khẩu không đúng!\nTruy cập bị từ chối.",
                    "Truy cập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            lvLoginLog.Items.Insert(0, item); // Thêm vào đầu danh sách
            txtPassword.Clear();
        }

        private void btnRING_Click(object sender, EventArgs e)
        {
            string currentTime = DateTime.Now.ToString("M/d/yyyy h:mm:ss tt");
            ListViewItem item = new ListViewItem(currentTime);
            item.SubItems.Add("Thiết kế mô hình!");
            item.SubItems.Add("Chấp nhận");
            item.BackColor = Color.LightBlue;

            lvLoginLog.Items.Insert(0, item);

            MessageBox.Show("Chuông đã được bấm!\nYêu cầu hỗ trợ từ thiết kế mô hình.",
                "Chuông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

  
}