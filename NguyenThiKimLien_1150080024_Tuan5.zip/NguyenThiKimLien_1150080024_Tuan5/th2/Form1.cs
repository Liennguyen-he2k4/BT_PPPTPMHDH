﻿using System;
using System.Drawing;
using System.Windows.Forms;
using th2;
namespace th2
{
    public partial class Form1 : Form
    {
        private Panel pnlHeader;
        private Label lblHeader;
        private Label lblTenKhachHang;
        private TextBox txtTenKhachHang;
        private Label lblDichVu;
        private CheckBox chkLayCaoRang;
        private CheckBox chkTayTrangRang;
        private CheckBox chkHanRang;
        private CheckBox chkBeRang;
        private CheckBox chkBocRang;
        private Label lblGiaLayCao;
        private Label lblGiaTayTrang;
        private Label lblGiaHanRang;
        private Label lblGiaBeRang;
        private Label lblGiaBocRang;
        private NumericUpDown nudHanRang;
        private NumericUpDown nudBeRang;
        private NumericUpDown nudBocRang;
        private Label lblChucNang;
        private Button btnTinhTien;
        private TextBox txtTongTien;
        private Button btnThoat;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form
            this.Text = "Form1";
            this.Size = new Size(650, 580);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.LightGray;

            // Panel Header
            this.pnlHeader = new Panel();
            this.pnlHeader.Location = new Point(0, 0);
            this.pnlHeader.Size = new Size(650, 80);
            this.pnlHeader.BackColor = Color.LimeGreen;

            // Label Header
            this.lblHeader = new Label();
            this.lblHeader.Location = new Point(20, 25);
            this.lblHeader.Size = new Size(600, 30);
            this.lblHeader.Text = "PHÒNG KHÁM NHA KHOA HẢI ÂU";
            this.lblHeader.Font = new Font("Microsoft Sans Serif", 18, FontStyle.Bold);
            this.lblHeader.ForeColor = Color.White;
            this.lblHeader.TextAlign = ContentAlignment.MiddleLeft;

            this.pnlHeader.Controls.Add(this.lblHeader);

            // Label Tên khách hàng
            this.lblTenKhachHang = new Label();
            this.lblTenKhachHang.Location = new Point(30, 100);
            this.lblTenKhachHang.Size = new Size(120, 25);
            this.lblTenKhachHang.Text = "Tên khách hàng:";
            this.lblTenKhachHang.Font = new Font("Microsoft Sans Serif", 10);

            // TextBox Tên khách hàng
            this.txtTenKhachHang = new TextBox();
            this.txtTenKhachHang.Location = new Point(180, 98);
            this.txtTenKhachHang.Size = new Size(350, 23);
            this.txtTenKhachHang.Font = new Font("Microsoft Sans Serif", 10);

            // Label Dịch vụ
            this.lblDichVu = new Label();
            this.lblDichVu.Location = new Point(30, 140);
            this.lblDichVu.Size = new Size(150, 25);
            this.lblDichVu.Text = "Dịch vụ tại phòng khám:";
            this.lblDichVu.Font = new Font("Microsoft Sans Serif", 10);

            // CheckBox Lấy cao răng
            this.chkLayCaoRang = new CheckBox();
            this.chkLayCaoRang.Location = new Point(50, 180);
            this.chkLayCaoRang.Size = new Size(120, 25);
            this.chkLayCaoRang.Text = "Lấy cao răng";
            this.chkLayCaoRang.Font = new Font("Microsoft Sans Serif", 9);

            // Label giá lấy cao răng
            this.lblGiaLayCao = new Label();
            this.lblGiaLayCao.Location = new Point(350, 180);
            this.lblGiaLayCao.Size = new Size(120, 25);
            this.lblGiaLayCao.Text = "50.000đ/2 hàm";
            this.lblGiaLayCao.Font = new Font("Microsoft Sans Serif", 9);

            // CheckBox Tẩy trắng răng
            this.chkTayTrangRang = new CheckBox();
            this.chkTayTrangRang.Location = new Point(50, 210);
            this.chkTayTrangRang.Size = new Size(120, 25);
            this.chkTayTrangRang.Text = "Tẩy trắng răng";
            this.chkTayTrangRang.Font = new Font("Microsoft Sans Serif", 9);
            this.chkTayTrangRang.Checked = true;

            // Label giá tẩy trắng răng
            this.lblGiaTayTrang = new Label();
            this.lblGiaTayTrang.Location = new Point(350, 210);
            this.lblGiaTayTrang.Size = new Size(120, 25);
            this.lblGiaTayTrang.Text = "100.000đ/2 hàm";
            this.lblGiaTayTrang.Font = new Font("Microsoft Sans Serif", 9);

            // CheckBox Hàn răng
            this.chkHanRang = new CheckBox();
            this.chkHanRang.Location = new Point(50, 240);
            this.chkHanRang.Size = new Size(120, 25);
            this.chkHanRang.Text = "Hàn răng";
            this.chkHanRang.Font = new Font("Microsoft Sans Serif", 9);

            // Label giá hàn răng
            this.lblGiaHanRang = new Label();
            this.lblGiaHanRang.Location = new Point(350, 240);
            this.lblGiaHanRang.Size = new Size(120, 25);
            this.lblGiaHanRang.Text = "100.000đ/1 răng";
            this.lblGiaHanRang.Font = new Font("Microsoft Sans Serif", 9);

            // NumericUpDown Hàn răng
            this.nudHanRang = new NumericUpDown();
            this.nudHanRang.Location = new Point(520, 242);
            this.nudHanRang.Size = new Size(60, 23);
            this.nudHanRang.Minimum = 1;
            this.nudHanRang.Maximum = 32;
            this.nudHanRang.Value = 1;

            // CheckBox Bẻ răng
            this.chkBeRang = new CheckBox();
            this.chkBeRang.Location = new Point(50, 270);
            this.chkBeRang.Size = new Size(120, 25);
            this.chkBeRang.Text = "Bẻ răng";
            this.chkBeRang.Font = new Font("Microsoft Sans Serif", 9);

            // Label giá bẻ răng
            this.lblGiaBeRang = new Label();
            this.lblGiaBeRang.Location = new Point(350, 270);
            this.lblGiaBeRang.Size = new Size(120, 25);
            this.lblGiaBeRang.Text = "10.000đ/1 răng";
            this.lblGiaBeRang.Font = new Font("Microsoft Sans Serif", 9);

            // NumericUpDown Bẻ răng
            this.nudBeRang = new NumericUpDown();
            this.nudBeRang.Location = new Point(520, 272);
            this.nudBeRang.Size = new Size(60, 23);
            this.nudBeRang.Minimum = 1;
            this.nudBeRang.Maximum = 32;
            this.nudBeRang.Value = 1;

            // CheckBox Bọc răng
            this.chkBocRang = new CheckBox();
            this.chkBocRang.Location = new Point(50, 300);
            this.chkBocRang.Size = new Size(120, 25);
            this.chkBocRang.Text = "Bọc răng";
            this.chkBocRang.Font = new Font("Microsoft Sans Serif", 9);

            // Label giá bọc răng
            this.lblGiaBocRang = new Label();
            this.lblGiaBocRang.Location = new Point(350, 300);
            this.lblGiaBocRang.Size = new Size(120, 25);
            this.lblGiaBocRang.Text = "1.000.000đ/1 răng";
            this.lblGiaBocRang.Font = new Font("Microsoft Sans Serif", 9);

            // NumericUpDown Bọc răng
            this.nudBocRang = new NumericUpDown();
            this.nudBocRang.Location = new Point(520, 302);
            this.nudBocRang.Size = new Size(60, 23);
            this.nudBocRang.Minimum = 1;
            this.nudBocRang.Maximum = 32;
            this.nudBocRang.Value = 1;

            // Label Chức năng
            this.lblChucNang = new Label();
            this.lblChucNang.Location = new Point(30, 350);
            this.lblChucNang.Size = new Size(100, 25);
            this.lblChucNang.Text = "Chức năng:";
            this.lblChucNang.Font = new Font("Microsoft Sans Serif", 10);

            // Button Tính tiền
            this.btnTinhTien = new Button();
            this.btnTinhTien.Location = new Point(50, 380);
            this.btnTinhTien.Size = new Size(80, 35);
            this.btnTinhTien.Text = "Tính tiền";
            this.btnTinhTien.Font = new Font("Microsoft Sans Serif", 9);
            this.btnTinhTien.UseVisualStyleBackColor = true;
            this.btnTinhTien.Click += new EventHandler(this.btnTinhTien_Click);

            // TextBox Tổng tiền
            this.txtTongTien = new TextBox();
            this.txtTongTien.Location = new Point(180, 385);
            this.txtTongTien.Size = new Size(200, 25);
            this.txtTongTien.Font = new Font("Microsoft Sans Serif", 10);
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.BackColor = Color.White;
            this.txtTongTien.TextAlign = HorizontalAlignment.Right;

            // Button Thoát
            this.btnThoat = new Button();
            this.btnThoat.Location = new Point(420, 380);
            this.btnThoat.Size = new Size(80, 35);
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Font = new Font("Microsoft Sans Serif", 9);
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new EventHandler(this.btnThoat_Click);

            // Add all controls to form
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.lblTenKhachHang);
            this.Controls.Add(this.txtTenKhachHang);
            this.Controls.Add(this.lblDichVu);
            this.Controls.Add(this.chkLayCaoRang);
            this.Controls.Add(this.lblGiaLayCao);
            this.Controls.Add(this.chkTayTrangRang);
            this.Controls.Add(this.lblGiaTayTrang);
            this.Controls.Add(this.chkHanRang);
            this.Controls.Add(this.lblGiaHanRang);
            this.Controls.Add(this.nudHanRang);
            this.Controls.Add(this.chkBeRang);
            this.Controls.Add(this.lblGiaBeRang);
            this.Controls.Add(this.nudBeRang);
            this.Controls.Add(this.chkBocRang);
            this.Controls.Add(this.lblGiaBocRang);
            this.Controls.Add(this.nudBocRang);
            this.Controls.Add(this.lblChucNang);
            this.Controls.Add(this.btnTinhTien);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.btnThoat);

            this.ResumeLayout(false);
        }

        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            // Kiểm tra tên khách hàng
            if (string.IsNullOrWhiteSpace(txtTenKhachHang.Text))
            {
                MessageBox.Show("Vui lòng nhập tên khách hàng!", "Cảnh báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTenKhachHang.Focus();
                return;
            }

            // Tính tổng tiền
            decimal tongTien = 0;

            // Lấy cao răng - 50,000đ/2 hàm
            if (chkLayCaoRang.Checked)
            {
                tongTien += 50000;
            }

            // Tẩy trắng răng - 100,000đ/2 hàm
            if (chkTayTrangRang.Checked)
            {
                tongTien += 100000;
            }

            // Hàn răng - 100,000đ/1 răng
            if (chkHanRang.Checked)
            {
                tongTien += 100000 * nudHanRang.Value;
            }

            // Bẻ răng - 10,000đ/1 răng
            if (chkBeRang.Checked)
            {
                tongTien += 10000 * nudBeRang.Value;
            }

            // Bọc răng - 1,000,000đ/1 răng
            if (chkBocRang.Checked)
            {
                tongTien += 1000000 * nudBocRang.Value;
            }

            // Hiển thị kết quả
            txtTongTien.Text = tongTien.ToString("N0") + " VNĐ";

            // Hiển thị thông báo
            if (tongTien == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất một dịch vụ!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"Khách hàng: {txtTenKhachHang.Text}\nTổng tiền thanh toán: {tongTien:N0} VNĐ",
                    "Thông tin thanh toán", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát không?", "Xác nhận thoát",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}