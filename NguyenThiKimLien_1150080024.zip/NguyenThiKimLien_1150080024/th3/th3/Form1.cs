﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using th3;
namespace th3
{
    public partial class Form1 : Form
    {
        private Panel pnlHeader;
        private Label lblHeader;
        private Label lblNhapSo;
        private TextBox txtNhapSo;
        private Button btnNhapSo;
        private ListBox lsbDaySo;
        private Label lblChucNang;
        private Button btnTangMoiPhanTu;
        private Button btnChonSoChanDau;
        private Button btnChonSoLeCuoi;
        private Button btnXoaPhanTuDangChon;
        private Button btnXoaPhanTuDau;
        private Button btnXoaPhanTuCuoi;
        private Button btnKetThucUngDung;
        private Button btnXoaDaySo;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form
            this.Text = "Form1";
            this.Size = new Size(650, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.LightGray;

            // Panel Header
            this.pnlHeader = new Panel();
            this.pnlHeader.Location = new Point(0, 0);
            this.pnlHeader.Size = new Size(650, 80);
            this.pnlHeader.BackColor = Color.Turquoise;

            // Label Header
            this.lblHeader = new Label();
            this.lblHeader.Location = new Point(20, 25);
            this.lblHeader.Size = new Size(600, 30);
            this.lblHeader.Text = "Ứng dụng xử lý dãy số";
            this.lblHeader.Font = new Font("Microsoft Sans Serif", 18, FontStyle.Bold);
            this.lblHeader.ForeColor = Color.Black;
            this.lblHeader.TextAlign = ContentAlignment.MiddleCenter;

            this.pnlHeader.Controls.Add(this.lblHeader);

            // Label Nhập số nguyên
            this.lblNhapSo = new Label();
            this.lblNhapSo.Location = new Point(30, 100);
            this.lblNhapSo.Size = new Size(120, 25);
            this.lblNhapSo.Text = "Nhập số nguyên:";
            this.lblNhapSo.Font = new Font("Microsoft Sans Serif", 10);

            // TextBox Nhập số
            this.txtNhapSo = new TextBox();
            this.txtNhapSo.Location = new Point(30, 130);
            this.txtNhapSo.Size = new Size(200, 23);
            this.txtNhapSo.Font = new Font("Microsoft Sans Serif", 10);
            this.txtNhapSo.KeyPress += new KeyPressEventHandler(this.txtNhapSo_KeyPress);
            this.txtNhapSo.KeyDown += new KeyEventHandler(this.txtNhapSo_KeyDown);

            // Button Nhập số
            this.btnNhapSo = new Button();
            this.btnNhapSo.Location = new Point(250, 125);
            this.btnNhapSo.Size = new Size(80, 30);
            this.btnNhapSo.Text = "Nhập số";
            this.btnNhapSo.Font = new Font("Microsoft Sans Serif", 9);
            this.btnNhapSo.BackColor = Color.LightBlue;
            this.btnNhapSo.UseVisualStyleBackColor = false;
            this.btnNhapSo.Click += new EventHandler(this.btnNhapSo_Click);

            // ListBox Dãy số
            this.lsbDaySo = new ListBox();
            this.lsbDaySo.Location = new Point(30, 170);
            this.lsbDaySo.Size = new Size(300, 350);
            this.lsbDaySo.Font = new Font("Microsoft Sans Serif", 10);
            this.lsbDaySo.BackColor = Color.White;

            // Label Chức năng
            this.lblChucNang = new Label();
            this.lblChucNang.Location = new Point(360, 170);
            this.lblChucNang.Size = new Size(100, 25);
            this.lblChucNang.Text = "Chức năng";
            this.lblChucNang.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);

            // Button Tăng mỗi phần tử lên 2
            this.btnTangMoiPhanTu = new Button();
            this.btnTangMoiPhanTu.Location = new Point(360, 200);
            this.btnTangMoiPhanTu.Size = new Size(200, 30);
            this.btnTangMoiPhanTu.Text = "Tăng mỗi phần tử lên 2";
            this.btnTangMoiPhanTu.Font = new Font("Microsoft Sans Serif", 9);
            this.btnTangMoiPhanTu.UseVisualStyleBackColor = true;
            this.btnTangMoiPhanTu.Click += new EventHandler(this.btnTangMoiPhanTu_Click);

            // Button Chọn số chẵn đầu
            this.btnChonSoChanDau = new Button();
            this.btnChonSoChanDau.Location = new Point(360, 240);
            this.btnChonSoChanDau.Size = new Size(200, 30);
            this.btnChonSoChanDau.Text = "Chọn số chẵn đầu";
            this.btnChonSoChanDau.Font = new Font("Microsoft Sans Serif", 9);
            this.btnChonSoChanDau.UseVisualStyleBackColor = true;
            this.btnChonSoChanDau.Click += new EventHandler(this.btnChonSoChanDau_Click);

            // Button Chọn số lẻ cuối
            this.btnChonSoLeCuoi = new Button();
            this.btnChonSoLeCuoi.Location = new Point(360, 280);
            this.btnChonSoLeCuoi.Size = new Size(200, 30);
            this.btnChonSoLeCuoi.Text = "Chọn số lẻ cuối";
            this.btnChonSoLeCuoi.Font = new Font("Microsoft Sans Serif", 9);
            this.btnChonSoLeCuoi.UseVisualStyleBackColor = true;
            this.btnChonSoLeCuoi.Click += new EventHandler(this.btnChonSoLeCuoi_Click);

            // Button Xóa phần tử đang chọn
            this.btnXoaPhanTuDangChon = new Button();
            this.btnXoaPhanTuDangChon.Location = new Point(360, 320);
            this.btnXoaPhanTuDangChon.Size = new Size(200, 30);
            this.btnXoaPhanTuDangChon.Text = "Xóa phần tử đang chọn";
            this.btnXoaPhanTuDangChon.Font = new Font("Microsoft Sans Serif", 9);
            this.btnXoaPhanTuDangChon.UseVisualStyleBackColor = true;
            this.btnXoaPhanTuDangChon.Click += new EventHandler(this.btnXoaPhanTuDangChon_Click);

            // Button Xóa phần tử đầu
            this.btnXoaPhanTuDau = new Button();
            this.btnXoaPhanTuDau.Location = new Point(360, 360);
            this.btnXoaPhanTuDau.Size = new Size(200, 30);
            this.btnXoaPhanTuDau.Text = "Xóa phần tử đầu";
            this.btnXoaPhanTuDau.Font = new Font("Microsoft Sans Serif", 9);
            this.btnXoaPhanTuDau.UseVisualStyleBackColor = true;
            this.btnXoaPhanTuDau.Click += new EventHandler(this.btnXoaPhanTuDau_Click);

            // Button Xóa phần tử cuối
            this.btnXoaPhanTuCuoi = new Button();
            this.btnXoaPhanTuCuoi.Location = new Point(360, 400);
            this.btnXoaPhanTuCuoi.Size = new Size(200, 30);
            this.btnXoaPhanTuCuoi.Text = "Xóa phần tử cuối";
            this.btnXoaPhanTuCuoi.Font = new Font("Microsoft Sans Serif", 9);
            this.btnXoaPhanTuCuoi.UseVisualStyleBackColor = true;
            this.btnXoaPhanTuCuoi.Click += new EventHandler(this.btnXoaPhanTuCuoi_Click);

            // Button Kết thúc ứng dụng
            this.btnKetThucUngDung = new Button();
            this.btnKetThucUngDung.Location = new Point(30, 540);
            this.btnKetThucUngDung.Size = new Size(150, 40);
            this.btnKetThucUngDung.Text = "Kết thúc ứng dụng";
            this.btnKetThucUngDung.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            this.btnKetThucUngDung.BackColor = Color.Red;
            this.btnKetThucUngDung.ForeColor = Color.White;
            this.btnKetThucUngDung.UseVisualStyleBackColor = false;
            this.btnKetThucUngDung.Click += new EventHandler(this.btnKetThucUngDung_Click);

            // Button Xóa dãy số
            this.btnXoaDaySo = new Button();
            this.btnXoaDaySo.Location = new Point(200, 540);
            this.btnXoaDaySo.Size = new Size(130, 40);
            this.btnXoaDaySo.Text = "Xóa dãy số";
            this.btnXoaDaySo.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            this.btnXoaDaySo.BackColor = Color.Gray;
            this.btnXoaDaySo.ForeColor = Color.White;
            this.btnXoaDaySo.UseVisualStyleBackColor = false;
            this.btnXoaDaySo.Click += new EventHandler(this.btnXoaDaySo_Click);

            // Add all controls to form
            this.Controls.Add(this.pnlHeader);
            this.Controls.Add(this.lblNhapSo);
            this.Controls.Add(this.txtNhapSo);
            this.Controls.Add(this.btnNhapSo);
            this.Controls.Add(this.lsbDaySo);
            this.Controls.Add(this.lblChucNang);
            this.Controls.Add(this.btnTangMoiPhanTu);
            this.Controls.Add(this.btnChonSoChanDau);
            this.Controls.Add(this.btnChonSoLeCuoi);
            this.Controls.Add(this.btnXoaPhanTuDangChon);
            this.Controls.Add(this.btnXoaPhanTuDau);
            this.Controls.Add(this.btnXoaPhanTuCuoi);
            this.Controls.Add(this.btnKetThucUngDung);
            this.Controls.Add(this.btnXoaDaySo);

            this.ResumeLayout(false);
        }

        // Chỉ cho phép nhập số và các phím điều khiển
        private void txtNhapSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Cho phép các phím: số, Backspace, Delete, dấu âm (-)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '-')
            {
                e.Handled = true;
            }

            // Chỉ cho phép dấu '-' ở đầu
            if (e.KeyChar == '-' && txtNhapSo.SelectionStart != 0)
            {
                e.Handled = true;
            }
        }

        // Xử lý phím Enter
        private void txtNhapSo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnNhapSo_Click(sender, e);
            }
        }

        // Thêm số vào ListBox
        private void btnNhapSo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNhapSo.Text))
            {
                MessageBox.Show("Vui lòng nhập một số nguyên!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNhapSo.Focus();
                return;
            }

            if (int.TryParse(txtNhapSo.Text, out int number))
            {
                lsbDaySo.Items.Add(number);
                txtNhapSo.Clear();
                txtNhapSo.Focus();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNhapSo.SelectAll();
                txtNhapSo.Focus();
            }
        }

        // Tăng mỗi phần tử lên 2
        private void btnTangMoiPhanTu_Click(object sender, EventArgs e)
        {
            if (lsbDaySo.Items.Count == 0)
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            for (int i = 0; i < lsbDaySo.Items.Count; i++)
            {
                int value = Convert.ToInt32(lsbDaySo.Items[i]);
                lsbDaySo.Items[i] = value + 2;
            }
        }

        // Chọn số chẵn đầu tiên
        private void btnChonSoChanDau_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lsbDaySo.Items.Count; i++)
            {
                int value = Convert.ToInt32(lsbDaySo.Items[i]);
                if (value % 2 == 0)
                {
                    lsbDaySo.SelectedIndex = i;
                    MessageBox.Show($"Đã chọn số chẵn đầu tiên: {value}", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            MessageBox.Show("Không tìm thấy số chẵn trong danh sách!", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Chọn số lẻ cuối cùng
        private void btnChonSoLeCuoi_Click(object sender, EventArgs e)
        {
            for (int i = lsbDaySo.Items.Count - 1; i >= 0; i--)
            {
                int value = Convert.ToInt32(lsbDaySo.Items[i]);
                if (value % 2 != 0)
                {
                    lsbDaySo.SelectedIndex = i;
                    MessageBox.Show($"Đã chọn số lẻ cuối cùng: {value}", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            MessageBox.Show("Không tìm thấy số lẻ trong danh sách!", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Xóa phần tử đang chọn
        private void btnXoaPhanTuDangChon_Click(object sender, EventArgs e)
        {
            if (lsbDaySo.SelectedIndex >= 0)
            {
                lsbDaySo.Items.RemoveAt(lsbDaySo.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một phần tử để xóa!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Xóa phần tử đầu
        private void btnXoaPhanTuDau_Click(object sender, EventArgs e)
        {
            if (lsbDaySo.Items.Count > 0)
            {
                lsbDaySo.Items.RemoveAt(0);
            }
            else
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Xóa phần tử cuối
        private void btnXoaPhanTuCuoi_Click(object sender, EventArgs e)
        {
            if (lsbDaySo.Items.Count > 0)
            {
                lsbDaySo.Items.RemoveAt(lsbDaySo.Items.Count - 1);
            }
            else
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Xóa toàn bộ dãy số
        private void btnXoaDaySo_Click(object sender, EventArgs e)
        {
            if (lsbDaySo.Items.Count > 0)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc muốn xóa toàn bộ dãy số?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    lsbDaySo.Items.Clear();
                }
            }
            else
            {
                MessageBox.Show("Danh sách đã rỗng!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Kết thúc ứng dụng
        private void btnKetThucUngDung_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát ứng dụng?", "Xác nhận thoát",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }


}